package analyzer;
/**
 * @desc build and analyze CFG of a given method.
 * @author you
 */
public class CFGAnalyzer {
	/**
	 * TODO: build and analyze CFG of a given method. 
	 * 		 You can create auxiliary classes/functions if needed. 
	 */
}
